import { Container } from "@mui/material";

const MainComponent = ({ children }) => {
  return <Container>{children}</Container>;
};

export default MainComponent;
